package com.maxultra.editor.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.maxultra.editor.utils.BitmapUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoEditorScreen(imageUri: Uri, onBack: () -> Unit) {
    val context = LocalContext.current
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(imageUri) { bmp = BitmapUtils.decodeSampledBitmapFromUri(context, imageUri) }
    Scaffold(topBar = { TopAppBar(title = { Text("Photo Editor") }) }) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            bmp?.let { Image(bitmap = it.asImageBitmap(), contentDescription = null, modifier = Modifier.weight(1f).fillMaxWidth()) }
            Button(onClick = onBack, modifier = Modifier.padding(16.dp)) { Text("Back") }
        }
    }
}
