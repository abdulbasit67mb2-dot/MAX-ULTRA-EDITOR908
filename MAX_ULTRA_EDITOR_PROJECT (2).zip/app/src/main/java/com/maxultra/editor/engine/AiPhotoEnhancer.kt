package com.maxultra.editor.engine

import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AiPhotoEnhancer {
    enum class EnhancementMode { PORTRAIT, LANDSCAPE, LOW_LIGHT }

    suspend fun enhance(
        source: Bitmap,
        mode: EnhancementMode = EnhancementMode.PORTRAIT,
        strength: Float = 0.85f
    ): Bitmap = withContext(Dispatchers.Default) {
        val w = source.width
        val h = source.height
        val pixels = IntArray(w * h)
        source.getPixels(pixels, 0, w, 0, 0, w, h)
        val outPixels = IntArray(w * h)

        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (Color.red(c) * 1.05f).toInt().coerceIn(0, 255)
            val g = (Color.green(c) * 1.05f).toInt().coerceIn(0, 255)
            val b = (Color.blue(c) * 1.03f).toInt().coerceIn(0, 255)
            outPixels[i] = Color.argb(Color.alpha(c), r, g, b)
        }
        Bitmap.createBitmap(outPixels, w, h, Bitmap.Config.ARGB_8888)
    }
}
