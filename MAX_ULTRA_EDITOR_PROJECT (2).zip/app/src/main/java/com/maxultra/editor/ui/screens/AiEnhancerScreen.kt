package com.maxultra.editor.ui.screens
import android.net.Uri
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun AiEnhancerScreen(imageUri: Uri, onBack: () -> Unit) { Text("AI Enhancer") }
