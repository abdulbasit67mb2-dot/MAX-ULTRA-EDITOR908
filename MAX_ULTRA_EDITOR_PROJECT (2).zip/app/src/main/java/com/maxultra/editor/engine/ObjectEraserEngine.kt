package com.maxultra.editor.engine

import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.ArrayDeque
import kotlin.math.*

object ObjectEraserEngine {
    suspend fun inpaint(source: Bitmap, mask: Bitmap, patchRadius: Int = 4): Bitmap = withContext(Dispatchers.Default) {
        val w = source.width
        val h = source.height
        val pixels = IntArray(w * h)
        val maskPixels = IntArray(w * h)
        source.getPixels(pixels, 0, w, 0, 0, w, h)
        mask.getPixels(maskPixels, 0, w, 0, 0, w, h)

        val flags = ByteArray(w * h)
        val queue = ArrayDeque<Int>()

        for (i in maskPixels.indices) {
            if (Color.alpha(maskPixels[i]) > 64) flags[i] = 2 else flags[i] = 0
        }

        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val idx = y * w + x
                if (flags[idx] == 2.toByte() && (flags[idx-1] == 0.toByte() || flags[idx+1] == 0.toByte())) {
                    flags[idx] = 1
                    queue.add(idx)
                }
            }
        }

        while (queue.isNotEmpty()) {
            val cur = queue.poll() ?: break
            val cx = cur % w
            val cy = cur / w
            var sumR = 0f; var sumG = 0f; var sumB = 0f; var totalWeight = 0f

            for (dy in -patchRadius..patchRadius) {
                val ny = cy + dy
                if (ny !in 0 until h) continue
                for (dx in -patchRadius..patchRadius) {
                    val nx = cx + dx
                    if (nx !in 0 until w) continue
                    val nIdx = ny * w + nx
                    if (flags[nIdx] == 0.toByte()) {
                        val dist = sqrt((dx*dx + dy*dy).toFloat()) + 0.001f
                        val weight = 1f / dist
                        val p = pixels[nIdx]
                        sumR += Color.red(p) * weight
                        sumG += Color.green(p) * weight
                        sumB += Color.blue(p) * weight
                        totalWeight += weight
                    }
                }
            }
            if (totalWeight > 0f) {
                pixels[cur] = Color.argb(255, (sumR/totalWeight).toInt().coerceIn(0,255), (sumG/totalWeight).toInt().coerceIn(0,255), (sumB/totalWeight).toInt().coerceIn(0,255))
                flags[cur] = 0
            }
        }
        Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }
}
