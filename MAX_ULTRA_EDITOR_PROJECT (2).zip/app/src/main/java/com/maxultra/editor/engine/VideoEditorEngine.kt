package com.maxultra.editor.engine

import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.*
import java.io.File

object VideoEditorEngine {
    data class VideoEditParams(val trimStartMs: Long = 0L, val trimEndMs: Long = 0L, val muteAudio: Boolean = false)

    fun exportVideo(
        context: Context,
        inputUri: Uri,
        params: VideoEditParams,
        onSuccess: (File) -> Unit,
        onError: (Exception) -> Unit
    ): Transformer {
        val outputDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "MAX_ULTRA_VIDEOS")
        outputDir.mkdirs()
        val outputFile = File(outputDir, "MAX_VIDEO_${System.currentTimeMillis()}.mp4")

        val mediaItem = MediaItem.Builder().setUri(inputUri).build()
        val editedMediaItem = EditedMediaItem.Builder(mediaItem).setRemoveAudio(params.muteAudio).build()

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) { onSuccess(outputFile) }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { onError(exportException) }
            })
            .build()

        transformer.start(editedMediaItem, outputFile.absolutePath)
        return transformer
    }
}
