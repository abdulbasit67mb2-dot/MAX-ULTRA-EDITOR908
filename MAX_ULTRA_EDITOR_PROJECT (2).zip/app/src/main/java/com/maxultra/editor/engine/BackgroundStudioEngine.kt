package com.maxultra.editor.engine

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

object BackgroundStudioEngine {
    enum class ReplacementMode { TRANSPARENT, SOLID_COLOR }

    private val segmenter = Segmentation.getClient(
        SelfieSegmenterOptions.Builder().setDeliveryMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
    )

    suspend fun processBackground(source: Bitmap, mode: ReplacementMode, solidColor: Int = Color.BLACK): Bitmap = withContext(Dispatchers.Default) {
        try {
            val mask = segmenter.process(InputImage.fromBitmap(source, 0)).await()
            val maskBuffer = mask.buffer
            val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
            val pixels = IntArray(source.width * source.height)
            source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)

            maskBuffer.rewind()
            for (i in pixels.indices) {
                val confidence = maskBuffer.float
                if (confidence < 0.5f && mode == ReplacementMode.TRANSPARENT) {
                    pixels[i] = Color.TRANSPARENT
                } else if (confidence < 0.5f) {
                    pixels[i] = solidColor
                }
            }
            Bitmap.createBitmap(pixels, source.width, source.height, Bitmap.Config.ARGB_8888)
        } catch (e: Exception) {
            source
        }
    }
}
